<?php
//ALL variable
$con= new mysqli('localhost','root','','project2')or die("Could not connect to mysql".mysqli_error($con));

?>